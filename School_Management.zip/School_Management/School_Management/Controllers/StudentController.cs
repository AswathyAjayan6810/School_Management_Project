﻿using Microsoft.AspNetCore.Mvc;
using School_Management.Models;
using StudentRegistration.Data;

namespace School_Management.Controllers
{
    public class StudentController : Controller
    {

        StudentDataAccess studentDataAccess = new StudentDataAccess();
      


        public IActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Registration(Student student)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    studentDataAccess.AddStudentRecord(student);

                  

                    return RedirectToAction("RegistrationSuccess");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, "An error occurred while saving the data.");
                }
            }

            return View(student);
        }

        public IActionResult RegistrationSuccess()
        {
            

            return View();
        }


    }
}
