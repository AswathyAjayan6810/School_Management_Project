﻿using System;
using System.Data;
using System.Data.SqlClient;
using School_Management.Models;

namespace StudentRegistration.Data
{
    public class StudentDataAccess
    {
        // Specify the connection string
        private readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\100887\Documents\Db_School_Mangement.mdf;Integrated Security=True;Connect Timeout=30";

        public string AddStudentRecord(Student student)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Insert the student record
                    string insertStudentQuery = "INSERT INTO Students (FirstName, LastName, Age, DOB, Gender, Email, PhoneNumber, Username, Password) " +
                                                "VALUES (@FirstName, @LastName, @Age, @DOB, @Gender, @Email, @PhoneNumber, @Username, @Password); " +
                                                "SELECT SCOPE_IDENTITY()";

                    using (SqlCommand cmd = new SqlCommand(insertStudentQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@FirstName", student.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", student.LastName);
                        cmd.Parameters.AddWithValue("@Age", student.Age);
                        cmd.Parameters.AddWithValue("@DOB", student.DOB);
                        cmd.Parameters.AddWithValue("@Gender", student.Gender);
                        cmd.Parameters.AddWithValue("@Email", student.Email);
                        cmd.Parameters.AddWithValue("@PhoneNumber", student.PhoneNumber);
                        cmd.Parameters.AddWithValue("@Username", student.Username);
                        cmd.Parameters.AddWithValue("@Password", student.Password);

                        // Execute the insert command and get the generated student ID
                        int studentId = Convert.ToInt32(cmd.ExecuteScalar());

                        if (student.Qualifications != null)
                        {
                            foreach (var qualification in student.Qualifications)
                            {
                                // Insert qualification records
                                string insertQualificationQuery = "INSERT INTO Qualifications (StudentId, CourseName, Percentage, YearOfPassing) " +
                                                                  "VALUES (@StudentId, @CourseName, @Percentage, @YearOfPassing)";
                                using (SqlCommand cmdQualification = new SqlCommand(insertQualificationQuery, con))
                                {
                                    cmdQualification.Parameters.AddWithValue("@StudentId", studentId);
                                    cmdQualification.Parameters.AddWithValue("@CourseName", qualification.CourseName);
                                    cmdQualification.Parameters.AddWithValue("@Percentage", qualification.Percentage);
                                    cmdQualification.Parameters.AddWithValue("@YearOfPassing", qualification.YearOfPassing);

                                    cmdQualification.ExecuteNonQuery();
                                }
                            }
                        }

                        con.Close();
                    }
                }

                return "Data saved successfully";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
