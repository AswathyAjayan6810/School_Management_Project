﻿namespace School_Management.Models
{
    public class SchoolMangage_Model
    {
    }
    public class Student
    {
        public int StudentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public List<Qualification> Qualifications { get; set; }
    }

    public class Qualification
    {
        public int QualificationId { get; set; }
        public int StudentId { get; set; }
        public string CourseName { get; set; }
        public decimal Percentage { get; set; }
        public int YearOfPassing { get; set; }
    }
}
